package org.synt.java.checks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.sonar.api.server.rule.RulesDefinition;
import org.sonar.check.Priority;
import org.sonar.check.Rule;
import org.sonar.plugins.java.api.JavaFileScanner;
import org.sonar.plugins.java.api.JavaFileScannerContext;
import org.sonar.plugins.java.api.tree.BaseTreeVisitor;
import org.sonar.plugins.java.api.tree.BinaryExpressionTree;
import org.sonar.plugins.java.api.tree.BlockTree;
import org.sonar.plugins.java.api.tree.CaseGroupTree;
import org.sonar.plugins.java.api.tree.CatchTree;
import org.sonar.plugins.java.api.tree.CompilationUnitTree;
import org.sonar.plugins.java.api.tree.DoWhileStatementTree;
import org.sonar.plugins.java.api.tree.ExpressionStatementTree;
import org.sonar.plugins.java.api.tree.ExpressionTree;
import org.sonar.plugins.java.api.tree.ForStatementTree;
import org.sonar.plugins.java.api.tree.IdentifierTree;
import org.sonar.plugins.java.api.tree.IfStatementTree;
import org.sonar.plugins.java.api.tree.LiteralTree;
import org.sonar.plugins.java.api.tree.MemberSelectExpressionTree;
import org.sonar.plugins.java.api.tree.MethodInvocationTree;
import org.sonar.plugins.java.api.tree.MethodTree;
import org.sonar.plugins.java.api.tree.StatementTree;
import org.sonar.plugins.java.api.tree.SwitchStatementTree;
import org.sonar.plugins.java.api.tree.Tree;
import org.sonar.plugins.java.api.tree.Tree.Kind;
import org.sonar.plugins.java.api.tree.TryStatementTree;
import org.sonar.plugins.java.api.tree.VariableTree;
import org.sonar.plugins.java.api.tree.WhileStatementTree;
import org.sonar.squidbridge.annotations.ActivatedByDefault;
import org.sonar.squidbridge.annotations.SqaleConstantRemediation;
import org.sonar.squidbridge.annotations.SqaleSubCharacteristic;
import org.synt.ccat.autorem.JavaAutoremChecker;
import org.synt.fedex.LocalFileReaderCheck;

@Rule(key = "SYN_CHARTOROWID_ORACLE_FUNCTION_CHECK", name = "SYN_CHARTOROWID_ORACLE_FUNCTION_CHECK", tags = {
"renault" }, priority = Priority.BLOCKER, description = "CATEGORY : SCALABILITY , Desc = This rule to find out CHARTOROWID oracle function in java source code")
@ActivatedByDefault
@SqaleSubCharacteristic(RulesDefinition.SubCharacteristics.LOGIC_CHANGEABILITY)
@SqaleConstantRemediation("0min")
public class SynCHARTOROWIDOracleFunctionCheck extends BaseTreeVisitor implements JavaFileScanner{

private JavaFileScannerContext context;	
	
private static Map<Integer,List<LiteralTree>> queryTrack = new HashMap();
private static List<LiteralTree> listTreeLst = new ArrayList();
private static Set<String> query = new HashSet();
private static Map<Integer,Boolean> queryTrack2 = new HashMap();
private String oracleFunction="CHARTOROWID";
private MethodInvocationTree methodTree;

	@Override
	public void scanFile(JavaFileScannerContext context) {
		Logger logger = Logger.getLogger(LocalFileReaderCheck.class);
		logger.info("Processing this rule SYN_CHARTOROWID_ORACLE_FUNCTION_CHECK");
		this.context = context;
		CompilationUnitTree cut = context.getTree();
		scan(cut);
	}
	
	
	@Override
	public void visitMethodInvocation(MethodInvocationTree tree) {
		String methodName = null;
		if (tree.methodSelect() != null && tree.methodSelect().is(Tree.Kind.MEMBER_SELECT)) {

			MemberSelectExpressionTree mset = (MemberSelectExpressionTree) tree.methodSelect();

			methodName = mset.identifier().name();

			IdentifierTree id = mset.identifier();
			if (id.is(Tree.Kind.IDENTIFIER)) {

				if (tree.arguments().size() > 0 && !tree.arguments().isEmpty()
						&& tree.arguments().get(0).is(Tree.Kind.STRING_LITERAL)) {

					LiteralTree literalTreeImpl = (LiteralTree) tree.arguments().get(0);
					String value = literalTreeImpl.token().text();

					if (("append").equals(methodName) &&

							value.toUpperCase().contains(oracleFunction)
							&& (value.toUpperCase()
									.substring(value.toUpperCase().indexOf(oracleFunction) - 1,
											value.toUpperCase().indexOf(oracleFunction))
									.equals(" ")
									|| value.toUpperCase()
											.substring(value.toUpperCase().indexOf(oracleFunction) - 1,
													value.toUpperCase().indexOf(oracleFunction))
											.equals("(")
									|| value.toUpperCase()
											.substring(value.toUpperCase().indexOf(oracleFunction) - 1,
													value.toUpperCase().indexOf(oracleFunction))
											.equals(")")
									|| value.toUpperCase()
											.substring(value.toUpperCase().indexOf(oracleFunction) - 1,
													value.toUpperCase().indexOf(oracleFunction))
											.equals(","))
							&& (value.toUpperCase()
									.substring(value.toUpperCase().indexOf(oracleFunction) + oracleFunction.length(),
											value.toUpperCase().indexOf(oracleFunction) + oracleFunction.length() + 1)
									.equals(" ")
									|| value.toUpperCase().substring(
											value.toUpperCase().indexOf(oracleFunction) + oracleFunction.length(),
											value.toUpperCase().indexOf(oracleFunction) + oracleFunction.length() + 1)
											.equals("(")
									|| value.toUpperCase().substring(
											value.toUpperCase().indexOf(oracleFunction) + oracleFunction.length(),
											value.toUpperCase().indexOf(oracleFunction) + oracleFunction.length() + 1)
											.equals(")")
									|| value.toUpperCase().substring(
											value.toUpperCase().indexOf(oracleFunction) + oracleFunction.length(),
											value.toUpperCase().indexOf(oracleFunction) + oracleFunction.length() + 1)
											.equals(","))) {
						context.addIssue(tree, this, oracleFunction + "Oracle function is used. ");
					}
				}
			}
		}

		super.visitMethodInvocation(tree);
	}

	@Override
	public void visitCatch(CatchTree tree) {
		BlockTree catchBlock = tree.block();
		String methodName=null;
		if (catchBlock != null) {
			for (StatementTree sTree : catchBlock.body()) {
				if (sTree != null && sTree.is(Tree.Kind.THROW_STATEMENT)) {

				} else if (sTree != null && sTree.is(Tree.Kind.EXPRESSION_STATEMENT)) {
					ExpressionStatementTree eSTree = (ExpressionStatementTree) sTree;

					ExpressionTree esTree = eSTree.expression();
					if (esTree != null && esTree.is(Kind.METHOD_INVOCATION)) {
						methodTree = (MethodInvocationTree) esTree;
						
					if (methodTree.arguments() != null ) {
						for (ExpressionTree exptree : methodTree.arguments()) {
							if (exptree != null && exptree.is(Tree.Kind.STRING_LITERAL)) {
							MemberSelectExpressionTree mset = (MemberSelectExpressionTree) methodTree.methodSelect();

						methodName = mset.identifier().name();
						if(methodName.equals("append")){
 
				
								LiteralTree lTree = (LiteralTree) exptree;
								if (lTree.value().toUpperCase().contains(oracleFunction) && (lTree.value().toUpperCase()
										.substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1,
												lTree.value().toUpperCase().indexOf(oracleFunction))
										.equals(" ")
										|| lTree.value().toUpperCase()
												.substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1,
														lTree.value().toUpperCase().indexOf(oracleFunction))
												.equals("(")
										|| lTree.value().toUpperCase()
												.substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1,
														lTree.value().toUpperCase().indexOf(oracleFunction))
												.equals(")")
										|| lTree.value().toUpperCase()
												.substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1,
														lTree.value().toUpperCase().indexOf(oracleFunction))
												.equals(","))
										&& (lTree.value().toUpperCase()
												.substring(
														lTree.value().toUpperCase().indexOf(oracleFunction)
																+ oracleFunction.length(),
														lTree.value().toUpperCase().indexOf(oracleFunction)
																+ oracleFunction.length() + 1)
												.equals(" ")
												|| lTree.value().toUpperCase()
														.substring(
																lTree.value().toUpperCase().indexOf(oracleFunction)
																		+ oracleFunction.length(),
																lTree.value().toUpperCase().indexOf(oracleFunction)
																		+ oracleFunction.length() + 1)
														.equals("(")
												|| lTree.value().toUpperCase()
														.substring(
																lTree.value().toUpperCase().indexOf(oracleFunction)
																		+ oracleFunction.length(),
																lTree.value().toUpperCase().indexOf(oracleFunction)
																		+ oracleFunction.length() + 1)
														.equals(")")
												|| lTree.value().toUpperCase()
														.substring(
																lTree.value().toUpperCase().indexOf(oracleFunction)
																		+ oracleFunction.length(),
																lTree.value().toUpperCase().indexOf(oracleFunction)
																		+ oracleFunction.length() + 1)
														.equals(","))) {
									JavaAutoremChecker.checkAutorem(this, lTree, this.context);
									context.addIssue(lTree, this, oracleFunction + " Oracle function is used. ");
								}
								}
								}
							}
						}
					}
				} else if (sTree != null && sTree.is(Tree.Kind.VARIABLE)) {
					VariableTree vTree = (VariableTree) sTree;
					this.visitVariable(vTree);
				} 
			}
		}
	}
	
	@Override
	public void visitVariable(VariableTree tree){
	 ExpressionTree exp= tree.initializer();
	 
	 BinaryExpressionTree binaryExpTree=null;
	 if(exp instanceof BinaryExpressionTree)
		 binaryExpTree=(BinaryExpressionTree)exp;
	 
	 if(binaryExpTree !=null){
	 this.visitBinaryExpressionn(binaryExpTree);
	  }
	 
	 if(null!= exp && exp.is(Kind.STRING_LITERAL)){
		 LiteralTree lTree=(LiteralTree) exp;
		 if (lTree.value().toUpperCase().contains(oracleFunction) && ( lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1, lTree.value().toUpperCase().indexOf(oracleFunction)).equals(" ")
			|| lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1, lTree.value().toUpperCase().indexOf(oracleFunction)).equals("(") || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1, lTree.value().toUpperCase().indexOf(oracleFunction)).equals(")") || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1, lTree.value().toUpperCase().indexOf(oracleFunction)).equals(",")  )
			&& (lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length(), lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length()+1).equals(" ")
			|| lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction)+oracleFunction.length(), lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length()+1).equals("(") || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction)+oracleFunction.length(), lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length()+1).equals(")") || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction)+oracleFunction.length(), lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length()+1).equals(",") )){
			    JavaAutoremChecker.checkAutorem(this,lTree, this.context);
				context.addIssue(lTree, this, oracleFunction+" Oracle function is used.");
		 }
	 }
	 super.visitVariable(tree);
	}
	
	
	private void visitBinaryExpressionn(BinaryExpressionTree tree){
		ExpressionTree leftOp=tree.leftOperand();
		ExpressionTree rightOp=tree.rightOperand();
		
		if(rightOp!=null && rightOp.is(Kind.STRING_LITERAL)){
			LiteralTree lTree=(LiteralTree) rightOp;
			if (lTree.value().toUpperCase().contains(oracleFunction) && ( lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1, lTree.value().toUpperCase().indexOf(oracleFunction)).equals(" ")
			   || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1, lTree.value().toUpperCase().indexOf(oracleFunction)).equals("(") || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1, lTree.value().toUpperCase().indexOf(oracleFunction)).equals(")") || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1, lTree.value().toUpperCase().indexOf(oracleFunction)).equals(",")  )
			   && (lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length(), lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length()+1).equals(" ")
			   || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction)+oracleFunction.length(), lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length()+1).equals("(") || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction)+oracleFunction.length(), lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length()+1).equals(")") || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction)+oracleFunction.length(), lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length()+1).equals(",") )){ 
				 if(!query.contains(lTree.value().toUpperCase())){
					 if(!queryTrack2.containsKey(lTree.token().line())){
					 query.add(lTree.value().toUpperCase());
					listTreeLst.add( lTree);
					 queryTrack.put(lTree.token().line(), listTreeLst);
					 queryTrack2.put(lTree.token().line(), false);
					 }
				 }
				
			 } 
		}if(leftOp!=null && tree.operatorToken().text().equals("+") && leftOp instanceof BinaryExpressionTree){
			visitBinaryExpressionn((BinaryExpressionTree)leftOp);
		}else if(leftOp!=null && leftOp.is(Kind.STRING_LITERAL)){
			LiteralTree lTree=(LiteralTree) leftOp;
			if (lTree.value().toUpperCase().contains(oracleFunction) && ( lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1, lTree.value().toUpperCase().indexOf(oracleFunction)).equals(" ")
			    || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1, lTree.value().toUpperCase().indexOf(oracleFunction)).equals("(") || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1, lTree.value().toUpperCase().indexOf(oracleFunction)).equals(")") || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1, lTree.value().toUpperCase().indexOf(oracleFunction)).equals(",")  )
				&& (lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length(), lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length()+1).equals(" ")
				|| lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction)+oracleFunction.length(), lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length()+1).equals("(") || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction)+oracleFunction.length(), lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length()+1).equals(")") || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction)+oracleFunction.length(), lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length()+1).equals(",") )){ 
				 if(!query.contains(lTree.value().toUpperCase())){
					 if(!queryTrack2.containsKey(lTree.token().line())){
						 query.add(lTree.value().toUpperCase());
						 listTreeLst.add(lTree);
						 queryTrack.put(lTree.token().line(), listTreeLst);
						 queryTrack2.put(lTree.token().line(), false);
					 }
				 }
			 } 
		}
		
		if(!queryTrack.isEmpty()){
			for(Map.Entry<Integer,List<LiteralTree>> entry:queryTrack.entrySet()){
				 for(Map.Entry<Integer,Boolean> entry1:queryTrack2.entrySet()){
				 if((entry1.getKey().intValue()==entry.getKey().intValue()) && entry1.getValue()==false){
				  List<LiteralTree> lstTemp = entry.getValue();
				   for(LiteralTree lt:lstTemp){
					   JavaAutoremChecker.checkAutorem(this,lt, this.context);
					   context.addIssue(lt, this, oracleFunction+" Oracle function is used.");
				   }
				   entry1.setValue(true);
				  }
				 }
			 }
			 query.clear();
			 listTreeLst.clear();
			 queryTrack.clear();
		}
		
		
		super.visitBinaryExpression(tree);	
	}
	
	 @Override
	 public void visitMethod(MethodTree tree){
		 BlockTree bTree=tree.block();
		if (bTree != null) {
			for (StatementTree sTree : bTree.body()) {
				if (sTree != null && sTree.is(Kind.VARIABLE)) {
					VariableTree vTree = (VariableTree) sTree;
					this.visitVariable(vTree);
				}else if (sTree.is(Kind.EXPRESSION_STATEMENT)) {
					ExpressionStatementTree est = (ExpressionStatementTree) sTree;
					ExpressionTree et = est.expression();
					if (et != null && et.is(Kind.METHOD_INVOCATION)) {
						MethodInvocationTree methodInvoke = (MethodInvocationTree) et;
						this.visitMethodInvocation(methodInvoke);
					}
				}
				 else if (sTree.is(Kind.IF_STATEMENT)) {
					this.visitIfStatement((IfStatementTree) sTree);
				} else if (sTree.is(Kind.TRY_STATEMENT)) {
					this.visitTryStatement((TryStatementTree) sTree);
				} else if (sTree.is(Kind.FOR_STATEMENT)) {
					this.visitForStatement((ForStatementTree) sTree);
				}else if (sTree.is(Kind.WHILE_STATEMENT)){
					this.visitWhileStatement((WhileStatementTree) sTree);
				}else if (sTree.is(Kind.SWITCH_STATEMENT)){
					this.visitSwitchStatement((SwitchStatementTree) sTree);
				}else if(sTree.is(Kind.DO_STATEMENT)){
					this.visitDoWhileStatement((DoWhileStatementTree) sTree);
				}
			}
		}
	}
	 
	@Override
	 public void visitSwitchStatement(SwitchStatementTree tree){
		 for(CaseGroupTree cgt: tree.cases()){
			 if(cgt.body()!=null){
				 for(StatementTree sTree:cgt.body()){
					 if (sTree != null && sTree.is(Kind.EXPRESSION_STATEMENT)) {
						ExpressionStatementTree esTree =(ExpressionStatementTree) sTree;
						ExpressionTree expTree = esTree.expression();
						if(expTree != null && expTree.is(Kind.VARIABLE)){
							VariableTree vTree = (VariableTree) expTree;
							this.visitVariable(vTree);
						}
						
						if(expTree != null && expTree instanceof BinaryExpressionTree ){
							BinaryExpressionTree beTree = (BinaryExpressionTree) expTree;
							this.visitBinaryExpression(beTree);
						}
						 
						if(expTree != null && expTree.is(Kind.STRING_LITERAL)){
							 LiteralTree lTree=(LiteralTree) expTree;
							 if (lTree.value().toUpperCase().contains(oracleFunction) && ( lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1, lTree.value().toUpperCase().indexOf(oracleFunction)).equals(" ")
								|| lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1, lTree.value().toUpperCase().indexOf(oracleFunction)).equals("(") || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1, lTree.value().toUpperCase().indexOf(oracleFunction)).equals(")") || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) - 1, lTree.value().toUpperCase().indexOf(oracleFunction)).equals(",")  )
								&& (lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length(), lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length()+1).equals(" ")
								|| lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction)+oracleFunction.length(), lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length()+1).equals("(") || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction)+oracleFunction.length(), lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length()+1).equals(")") || lTree.value().toUpperCase().substring(lTree.value().toUpperCase().indexOf(oracleFunction)+oracleFunction.length(), lTree.value().toUpperCase().indexOf(oracleFunction) + oracleFunction.length()+1).equals(",") )){
								    JavaAutoremChecker.checkAutorem(this,lTree, this.context);
									context.addIssue(lTree, this, oracleFunction+" Oracle function is used.");
							 }
						}
					}
				}
			}
		}
	}
}
